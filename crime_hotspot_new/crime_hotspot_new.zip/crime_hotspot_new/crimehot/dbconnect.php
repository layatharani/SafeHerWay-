<?php
$connect=mysqli_connect("localhost","root","","crime_hotspot_new");
?>